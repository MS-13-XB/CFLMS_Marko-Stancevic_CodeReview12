

<!-- navbar dropdown -->
	<!-- 	<div class="pos-f-t">
	  <div class="collapse" id="navbarToggleExternalContent">
	    <div class="bg-dark p-4">
	      <h4 class="text-white">Collapsed content</h4>
	      <span class="text-muted">Toggleable via the navbar brand.</span>
	    </div>
	  </div>
	  <nav class="navbar navbar-dark bg-dark">
	    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
	      <span class="navbar-toggler-icon"></span>
	    </button>
	  </nav>
	</div> -->

	<?php get_header(); ?>


	<h1 style="text-align: center;">Travel to your destiny</h1>
	<hr>
	
	<div class="container-fluid">
	<div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-4 m-4 justify-content-around">

<!-- 
	<div class="card-deck"> -->
  <!-- <div class="card">
    <img src="..." class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
    </div>
    <div class="card-footer">
      <small class="text-muted">Last updated 3 mins ago</small>
    </div>
  </div> -->



	

		<!-- Here coding -->
				
	

 	 	<?php if(have_posts()) : ?> <!--  If there are posts available  -->
                                    <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop-->
											<!-- <div class="card-columns">
 -->									<div class="card">
 		
 									<div class="card-body">


                                    <a href="<?php the_permalink(); ?>"><!--retrieves URL for the permalink-->
                                    <h1><?php the_title(); ?></h1><!--retrieves blog title-->
                                    </a>
                                    <p class="card-text"><?php the_time('F j, Y g:i a'); ?></p><!--retrieves date blog entry was created-->
                                    <p class="card-text"><?php the_author(); ?></p><!--retrieves author of blog entry-->
                                    <?php the_excerpt(); ?><!--retrieves excerpt-->
                                    <!-- <img> --><?php if(has_post_thumbnail()) : ?>
                                    <?php the_post_thumbnail(array(180)); ?> <!--Größe des thumbnails-->
                                    					


                                    <?php endif; ?><!-- </img> -->
                                    </div>
									</div>
								<!-- </div> -->

                                    <?php endwhile; ?><!--end the while loop-->
									
                                    <?php else :?> <!-- if no posts are found then: -->
                                    <p class="card-text">No posts found</p>
                                    <?php endif; ?> <!-- end if -->
								    <?php if(is_active_sidebar('sidebar')):
								    dynamic_sidebar('sidebar');
								    endif; ?>
	
   		 
  		
	</div>

<!-- 	</div> -->
</div>


	<?php wp_footer(); ?>
			

	

</body>
</html>